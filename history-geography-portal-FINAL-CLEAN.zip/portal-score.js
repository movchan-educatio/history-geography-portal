/* Portal score synchronization — single Firebase scoring layer */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getDatabase, ref, runTransaction } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyAF2acxaXKOH4e4RoAUQcqMgX4s65xttSw",
  authDomain: "movchan-portal.firebaseapp.com",
  databaseURL: "https://movchan-portal-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "movchan-portal",
  storageBucket: "movchan-portal.firebasestorage.app",
  messagingSenderId: "535915495927",
  appId: "1:535915495927:web:71f899ea2876ee129c2ef2"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);
let currentUser = null;
let authReadyResolve;
const authReady = new Promise(resolve => { authReadyResolve = resolve; });

const pendingKey = kind => `portal_pending_${kind}`;
function readPending(kind) {
  try { return JSON.parse(localStorage.getItem(pendingKey(kind)) || '{}') || {}; }
  catch { return {}; }
}
function writePending(kind, value) {
  localStorage.setItem(pendingKey(kind), JSON.stringify(value || {}));
}

function getCurrentWeekKey() {
  const d = new Date();
  const day = d.getDay() || 7;
  d.setDate(d.getDate() + 4 - day);
  const yearStart = new Date(d.getFullYear(), 0, 1);
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return `${d.getFullYear()}-W${String(weekNo).padStart(2, '0')}`;
}

async function requireUser() {
  await authReady;
  return currentUser;
}

function setSyncStatus(type, text) {
  const el = document.getElementById(`${type}-sync-status`);
  if (el) el.textContent = text;
}

async function awardSubjectQuiz(subject, themeId, score) {
  const target = Math.max(0, Number(score) || 0);
  if (!themeId || target <= 0) return false;
  const user = await requireUser();
  if (!user) {
    const pending = readPending(subject);
    pending[themeId] = Math.max(Number(pending[themeId]) || 0, target);
    writePending(subject, pending);
    console.warn(`Портал: ${subject} — користувач ще не авторизований, результат поставлено в чергу.`);
    return false;
  }

  const path = `users/${user.uid}`;
  try {
    await runTransaction(ref(database, path), data => {
      data = data || {};
      data.name = data.name || user.displayName || 'Учень';
      const isHistory = subject === 'history';
      const globalMapKey = isHistory ? 'history_quiz_best_by_theme' : 'geography_quiz_best_by_theme';
      const totalKey = isHistory ? 'total_history_points' : 'total_geography_points';
      const weekMapKey = isHistory ? 'week_history_quiz_best_by_theme' : 'week_geography_quiz_best_by_theme';
      const weekDateKey = isHistory ? 'history_quiz_week_key' : 'geography_quiz_week_key';
      const weekPointsKey = isHistory ? 'week_history_points' : 'week_geography_points';

      const globalMap = (data[globalMapKey] && typeof data[globalMapKey] === 'object') ? data[globalMapKey] : {};
      const oldGlobal = Number(globalMap[themeId]) || 0;
      const globalBest = Math.max(oldGlobal, target);
      const globalDelta = globalBest - oldGlobal;
      globalMap[themeId] = globalBest;

      const week = getCurrentWeekKey();
      const weekMap = data[weekDateKey] === week && data[weekMapKey] && typeof data[weekMapKey] === 'object' ? data[weekMapKey] : {};
      const oldWeek = Number(weekMap[themeId]) || 0;
      const weekBest = Math.max(oldWeek, target);
      const weekDelta = weekBest - oldWeek;
      weekMap[themeId] = weekBest;

      data[globalMapKey] = globalMap;
      data[weekMapKey] = weekMap;
      data[weekDateKey] = week;
      data[totalKey] = Object.values(globalMap).reduce((s,v) => s + (Number(v) || 0), 0);
      data.score = (Number(data.score) || 0) + globalDelta;
      data[weekPointsKey] = (Number(data[weekPointsKey]) || 0) + weekDelta;
      data.week_score =
        (Number(data.week_history_points) || 0) +
        (Number(data.week_geography_points) || 0) +
        (Number(data.week_nmt_history_score) || 0) +
        (Number(data.week_nmt_geography_score) || 0) +
        (Number(data.week_truth_or_lie_points) || 0);
      return data;
    });
    console.log(`Портал: ${subject} ${themeId} → ${target} балів зараховано.`);
    return true;
  } catch (error) {
    console.error(`Портал: помилка ${subject} score`, error);
    const pending = readPending(subject);
    pending[themeId] = Math.max(Number(pending[themeId]) || 0, target);
    writePending(subject, pending);
    return false;
  }
}

async function awardNmt(subject, score, total) {
  const target = Math.max(0, Math.min(Number(total) || 30, Number(score) || 0));
  if (target <= 0) return false;
  const user = await requireUser();
  if (!user) {
    const pending = readPending(`nmt_${subject}`);
    pending.result = Math.max(Number(pending.result) || 0, target);
    pending.total = Number(total) || 30;
    writePending(`nmt_${subject}`, pending);
    setSyncStatus(subject, '⏳ Результат буде синхронізовано після входу через Google.');
    return false;
  }

  try {
    await runTransaction(ref(database, `users/${user.uid}`), data => {
      data = data || {};
      data.name = data.name || user.displayName || 'Учень';
      const scoreKey = `nmt_${subject}_score`;
      const totalKey = `nmt_${subject}_total`;
      const weekKey = subject === 'history' ? 'week_nmt_history_score' : 'week_nmt_geography_score';
      const bestKey = subject === 'history' ? 'week_nmt_history_best' : 'week_nmt_geography_best';
      const dateKey = subject === 'history' ? 'nmt_history_quiz_week_key' : 'nmt_geography_quiz_week_key';
      const oldGlobal = Number(data[scoreKey]) || 0;
      const globalBest = Math.max(oldGlobal, target);
      const globalDelta = globalBest - oldGlobal;
      const week = getCurrentWeekKey();
      const oldWeek = data[dateKey] === week ? Number(data[bestKey]) || 0 : 0;
      const weekBest = Math.max(oldWeek, target);
      const weekDelta = weekBest - oldWeek;
      data[scoreKey] = globalBest;
      data[totalKey] = Number(total) || 30;
      data.nmt_total_score = (Number(data.nmt_history_score) || 0) + (Number(data.nmt_geography_score) || 0);
      data.score = (Number(data.score) || 0) + globalDelta;
      data[weekKey] = (Number(data[weekKey]) || 0) + weekDelta;
      data[bestKey] = weekBest;
      data[dateKey] = week;
      data.week_score =
        (Number(data.week_history_points) || 0) +
        (Number(data.week_geography_points) || 0) +
        (Number(data.week_nmt_history_score) || 0) +
        (Number(data.week_nmt_geography_score) || 0) +
        (Number(data.week_truth_or_lie_points) || 0);
      return data;
    });
    writePending(`nmt_${subject}`, {});
    setSyncStatus(subject, '✅ Бал синхронізовано');
    console.log(`Портал: НМТ ${subject} → ${target} балів зараховано.`);
    return true;
  } catch (error) {
    console.error('Портал: помилка НМТ score', error);
    const pending = readPending(`nmt_${subject}`);
    pending.result = Math.max(Number(pending.result) || 0, target);
    pending.total = Number(total) || 30;
    writePending(`nmt_${subject}`, pending);
    setSyncStatus(subject, '⚠️ Не вдалося синхронізувати. Спробуйте ще раз.');
    return false;
  }
}

window.portalScore = {
  getCurrentUser: () => currentUser,
  awardHistoryQuizScore: (themeId, score) => awardSubjectQuiz('history', themeId, score),
  awardGeographyQuizScore: (themeId, score) => awardSubjectQuiz('geography', themeId, score),
  awardNmtScore: awardNmt
};
window.awardHistoryQuizScore = window.portalScore.awardHistoryQuizScore;
window.awardGeographyQuizScore = window.portalScore.awardGeographyQuizScore;
window.awardNmtPoint = awardNmt;

onAuthStateChanged(auth, async user => {
  currentUser = user;
  authReadyResolve(user);
  if (!user) return;

  // Надсилаємо тільки результати, які реально були отримані до готовності Auth.
  for (const subject of ['history','geography']) {
    const pending = readPending(subject);
    const entries = Object.entries(pending);
    if (!entries.length) continue;
    writePending(subject, {});
    for (const [themeId, score] of entries) await awardSubjectQuiz(subject, themeId, score);
  }
  for (const subject of ['history','geography']) {
    const key = `nmt_${subject}`;
    const pending = readPending(key);
    if (pending.result > 0) {
      writePending(key, {});
      await awardNmt(subject, pending.result, pending.total || 30);
    }
  }
});
